
package biblioteca;

import Views.FrmLogin;

public class Biblioteca {

    public static void main(String[] args) {
        FrmLogin login = new FrmLogin();
        login.setVisible(true);
    }
    
}
